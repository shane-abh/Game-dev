/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class LoginController {
    protected Player player;
    protected Stage primaryStage;
    protected ReceiverServer server;

    @FXML
    public TextField myIpText;

    @FXML
    public TextField usernameInput;

    @FXML
    public TextField joinInput;
    
    @FXML
    public void onNewGameAction(ActionEvent actionEvent) throws IOException {
        changeToGameState();
    }

//    @FXML
    public void onJoinGameAction(ActionEvent actionEvent) throws IOException {
        changeToGameState(true);
    }
    
    @FXML
    public void onCreditsAction(ActionEvent event) throws IOException {
       changeToCreditsState(); 
    }

    @FXML
    public void onHelpAction(ActionEvent event) throws IOException {
        changeToHelpState();
    }
    
    @FXML
    public void onBackAction(ActionEvent event) throws IOException {
        ChangetoBackState();
    }

    @FXML
    public void onQuitAction(ActionEvent event) {
        Platform.exit();
    }
    
    
    private void ChangetoBackState() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Parent root = loader.load();

        primaryStage.setTitle("Rock Paper Scissors");
        Scene scene = new Scene(root, 244.0, 650.0);

        // get controller
        LoginController loginController = (LoginController) loader.getController();
        loginController.init(player, primaryStage, server);

        // show scene
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();

    }
    
    private void changeToHelpState() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("help.fxml"));
        Parent root = loader.load();

        // show scene
        primaryStage.getScene().setRoot(root);
        primaryStage.show();

    }
    
    private void changeToCreditsState() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("credits.fxml"));
        Parent root = loader.load();
        
        // show scene
        primaryStage.getScene().setRoot(root);
        primaryStage.show();

    }

    protected void changeToGameState() throws IOException {
        changeToGameState(false);
    }

    protected void changeToGameState(boolean clickedJoin) throws IOException {
        // update username
        if(usernameInput.getText().isEmpty()){
            
            
        }else{
             player.username = usernameInput.getText();      

            // load new view
            FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
            Parent root = loader.load();

        
            Opponent opponent = null;
            // checked if join was clicked
            if (clickedJoin) {
                String[] input = joinInput.getText().split(":");
                //input 0 is IP and input 1 is port
                opponent = new Opponent(input[0], Integer.parseInt(input[1]));
            }

            // get controller
            GameController gameController = (GameController) loader.getController();
            gameController.init(player, primaryStage, server, opponent);

            // show scene
            primaryStage.getScene().setRoot(root);
            primaryStage.show();
        }
    }

    /**
     * Updates the view with player information and makes the player and stage available to the controller.
     * @param player
     * @param stage
     */
    public void init(Player player, Stage stage, ReceiverServer server) {
        this.player = player;
        this.primaryStage = stage;
        this.server = server;
        
        
        myIpText.setText(player.ip + ":" + player.port);
//        usernameInput.setText(player.username);
        usernameInput.setPromptText("Enter Username ");
    }


}
