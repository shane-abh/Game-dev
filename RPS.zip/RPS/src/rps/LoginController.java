/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class LoginController {
    protected Player player;
    protected Stage primaryStage;
    protected ReceiverServer server;

    @FXML
    public TextField myIpText;

    @FXML
    public TextField usernameInput;

    @FXML
    public TextField joinInput;
    
    @FXML
    public void onNewGameAction(ActionEvent actionEvent) throws IOException {
        changeToGameState();
    }

//    @FXML
    public void onJoinGameAction(ActionEvent actionEvent) throws IOException {
        changeToGameState(true);
    }

    protected void changeToGameState() throws IOException {
        changeToGameState(false);
    }

    protected void changeToGameState(boolean clickedJoin) throws IOException {
        // update username
        if(usernameInput.getText().isEmpty()){
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            String s = "Enter Username! ";
            alert.setContentText(s);
            alert.showAndWait();
            
        }else{
             player.username = usernameInput.getText();      

            // load new view
            FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
            Parent root = loader.load();

        
            Opponent opponent = null;
            // checked if join was clicked
            if (clickedJoin) {
                String[] input = joinInput.getText().split(":");
                //input 0 is IP and input 1 is port
                opponent = new Opponent(input[0], Integer.parseInt(input[1]));
            }

            // get controller
            GameController gameController = (GameController) loader.getController();
            gameController.init(player, primaryStage, server, opponent);

            // show scene
            primaryStage.getScene().setRoot(root);
            primaryStage.show();
        }
    }

    /**
     * Updates the view with player information and makes the player and stage available to the controller.
     * @param player
     * @param stage
     */
    public void init(Player player, Stage stage, ReceiverServer server) {
        this.player = player;
        this.primaryStage = stage;
        this.server = server;
        
        
        myIpText.setText(player.ip + ":" + player.port);
//        usernameInput.setText(player.username);
        usernameInput.setPromptText("Enter Username ");
    }
}
